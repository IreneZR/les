#!/usr/bin/env python

from les.runtime.thread_pool import ThreadPool
from les.utils import unittest

class ThreadPoolTest(unittest.TestCase):

  def test_wait(self):
    pass

if __name__ == '__main__':
  unittest.main()
