from scipy import sparse

class SparseMatrix(object):

  def is_empty(self): pass
  def get_num_rows(self): pass
  def get_num_columns(self): pass
  def get_num_entries(self): pass
