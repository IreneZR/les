from les.mp_model import MPModel
from les.mp_model.mp_model_builder.formats import mps
from les.mp_model.mp_model_builder import MPModelBuilder

decoder = mps.Decoder()
filename = "/home/ira/les/data/demos/demo2.mps"#"/home/ira/Downloads/demo4.mps"#"/home/ira/Downloads/Tasks/demo_3f.mps"
with open(filename, "r") as stream:
  decoder.decode(stream)
model = MPModelBuilder.build_from(decoder)
model.pprint()
